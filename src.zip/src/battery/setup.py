from setuptools import setup
import os
from glob import glob

package_name = 'battery'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='chan',
    maintainer_email='chan@example.com',
    description='PDIST120 battery percentage reader and server uploader',
    license='TODO',
    entry_points={
        'console_scripts': [
            'battery_node = battery.battery_node:main',
        ],
    },
)
